package com.kodery.pratz.marolator;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    public String string1="Calden Rocks";
    public TextView stringbox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stringbox =(TextView)findViewById(R.id.textView);

        Button button = (Button) findViewById(R.id.button23);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //stringbox.setText(string1);
                String resultURL = "http://192.168.0.6:3031/api/register";
                new RestOperation().execute(resultURL);
            }
        });



    }

    public class RestOperation extends AsyncTask<String,Void,String> {

        //final HttpClient httpClient = new

        @Override
        protected String doInBackground(String... params)
        {
            StringBuilder result= new StringBuilder();
            try{

                URL url = new URL(params[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(10000);
                urlConnection.setConnectTimeout(10000);
                urlConnection.setRequestMethod("GET");
                urlConnection.setRequestProperty("Content-Type","application/json");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while((line=bufferedReader.readLine()) != null){
                    result.append(line).append("\n");

                }

            }catch(IOException ex){
                return ex.toString();
            }
            return result.toString();
        }


        @Override
        protected void onPreExecute()
        {

            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String result)
        {
            super.onPostExecute(result);
            stringbox.setText(result);

        }
    }

}
